export { default as getInfoService } from "./getInfoService.js";
