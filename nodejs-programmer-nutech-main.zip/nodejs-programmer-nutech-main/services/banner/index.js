export { default as getBannerService } from "./getBannerService.js";
