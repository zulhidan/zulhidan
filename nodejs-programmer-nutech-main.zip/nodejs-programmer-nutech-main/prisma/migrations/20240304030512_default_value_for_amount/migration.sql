-- AlterTable
ALTER TABLE "balances" ALTER COLUMN "amount" SET DEFAULT 0;
