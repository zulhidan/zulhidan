/*
  Warnings:

  - You are about to drop the column `amount` on the `balances` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "balances" DROP COLUMN "amount",
ADD COLUMN     "balance" DOUBLE PRECISION NOT NULL DEFAULT 0;
